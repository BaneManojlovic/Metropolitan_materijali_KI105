/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak4;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.*;

/**
 *
 * @author manojlovic
 */
public class Zadatak4 extends JFrame{
    
    JPanel panel1 = new JPanel();
    JPanel panel2 = new JPanel();
    JPanel panel3 = new JPanel();
    JPanel panel4 = new JPanel();
    
    JLabel labela1 = new JLabel("Name:");
    JTextField tekstPolje1 = new JTextField();
    JLabel labela2 = new JLabel("Password:");
    JTextField tekstPolje2 = new JTextField();
    JLabel labela3 = new JLabel("Email:");
    JTextField tekstPolje3 = new JTextField();
    JLabel labela4 = new JLabel("Zip Code:");
    JTextField tekstPolje4 = new JTextField();
    JLabel labela5 = new JLabel("Year of Birth:");
    JTextField tekstPolje5 = new JTextField();
    JLabel labela6 = new JLabel("Phone number:");
    JTextField tekstPolje6 = new JTextField();
    
    JTextArea textPovrsina = new JTextArea();
    
    JButton dugme1 = new JButton("Insert");
    
    public static void main(String[] args) {
        new Zadatak4();
    }

    public Zadatak4() {
        setTitle("Subscription Form");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setupGUI();
        setResizable(false);
        setVisible(true);
    }
            
    public void setupGUI() {
        
         panel4.setLayout(new GridLayout(6, 2, 5, 5));
         panel4.add(labela1);
         panel4.add(tekstPolje1);
         panel4.add(labela2);
         panel4.add(tekstPolje2);
         panel4.add(labela3);
         panel4.add(tekstPolje3);
         panel4.add(labela4);
         panel4.add(tekstPolje4);
         panel4.add(labela5);
         panel4.add(tekstPolje5);
         panel4.add(labela6);
         panel4.add(tekstPolje6);
         
         panel3.setLayout(new GridLayout(1, 1, 5, 5));
         panel3.add(textPovrsina);
         
         panel2.setLayout(new GridLayout(1, 1, 5, 5));
         panel2.add(dugme1);
         
         add(panel4, BorderLayout.NORTH);
         add(panel3, BorderLayout.CENTER);
         add(panel2, BorderLayout.SOUTH);
         
    }
    
}

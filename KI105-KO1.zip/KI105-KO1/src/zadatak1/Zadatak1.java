/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak1;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Jovana
 */
public class Zadatak1 extends JFrame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Zadatak1();
    }

    public Zadatak1() {
        setTitle("Primer 1");
        setSize(500, 500);
        //setLocation(50, 50);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(randomBoja());
        setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        setupGUI();
        setVisible(true);
    }
    
    public void setupGUI(){
        JButton btnChange = new JButton("Change color");
        add(btnChange);
        add(new JButton("Hello"));
        add(new JButton("Hello"));
        add(new JButton("Hello"));
        add(new JButton("Hello"));
        add(new JButton("Hello"));
        add(new JButton("Hello"));
        JPanel grid = new JPanel(new GridLayout(3, 1));
        grid.add(new JLabel("1"));
        grid.add(new JLabel("2"));
        grid.add(new JLabel("3"));
        
        add(grid);
        
        btnChange.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().setBackground(randomBoja());
            }
        });
        
    }
    
    
    public static Color randomBoja(){
        Random r = new Random();
        
        return new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
    }
}

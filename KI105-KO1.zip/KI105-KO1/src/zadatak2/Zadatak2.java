/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak2;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Jovana
 */
public class Zadatak2 extends JFrame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Zadatak2();
    }

    public Zadatak2() {
        super.setTitle("Flight Reservation");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setupGUI();
        setResizable(false);
        setVisible(true);
    }

    public void setupGUI() {
        /**
         * Labels Date, From, To
         */
        JPanel labelsPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        labelsPanel.add(new JLabel("Date:"));
        labelsPanel.add(new JLabel("From:"));
        labelsPanel.add(new JLabel("To"));

        /**
         * Fields panel
         */
        JPanel filedsPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        filedsPanel.add(new JTextField());

        JComboBox<String> fromCombo = new JComboBox<>();
        fromCombo.addItem("Belgrade");
        fromCombo.addItem("London");
        fromCombo.addItem("Nis");
        filedsPanel.add(fromCombo);

        JComboBox<String> toCombo = new JComboBox<>();
        toCombo.addItem("New York");
        toCombo.addItem("LA");
        toCombo.addItem("Berlin");
        filedsPanel.add(toCombo);

        /**
         * Options part
         */
        JPanel optionsPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        
        JRadioButton radio1 = new JRadioButton("First class");       
        JRadioButton radio2 = new JRadioButton("Business");       
        JRadioButton radio3 = new JRadioButton("Coach");
        
        ButtonGroup group = new ButtonGroup();
        group.add(radio1);
        group.add(radio2);
        group.add(radio3);
        
        optionsPanel.add(radio1);
        optionsPanel.add(radio2);
        optionsPanel.add(radio3);
        optionsPanel.setBorder(new TitledBorder("Options"));

        JPanel panelNorth = new JPanel(new BorderLayout(10, 10));
        panelNorth.add(labelsPanel, BorderLayout.WEST);
        panelNorth.add(filedsPanel, BorderLayout.CENTER);
        panelNorth.add(optionsPanel, BorderLayout.EAST);
        panelNorth.setBorder(new EmptyBorder(10, 10, 10, 10));

        add(panelNorth, BorderLayout.NORTH);

        /**
         * CENTER AVAILABLE FLIGHTS
         */
        JPanel centerPanel = new JPanel(new GridLayout(1, 1));
        JTextArea availableTxt = new JTextArea();
        centerPanel.add(availableTxt);
        centerPanel.setBorder(new TitledBorder("Available Flights"));

        add(centerPanel, BorderLayout.CENTER);

        /**
         * SOUTH BUTTONS
         */
        JPanel southButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton searchBtn = new JButton("Search");
        southButtons.add(searchBtn);
        searchBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                availableTxt.setText("Belgrade - Berlin 17:30 100e \nBelgrade - London 18:30 120e");
            }
        });
        
        southButtons.add(new JButton("Purchase"));
        JButton btnExit = new JButton("Exit");
        southButtons.add(btnExit);
        
        btnExit.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(1);
            }
        });
        
        add(southButtons, BorderLayout.SOUTH);
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak1;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author Jovana
 */
public class SneskoPanel extends JPanel {

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        int w = getWidth();
        int h = getHeight();

        setBackground(Color.CYAN);

        g.setColor(Color.BLUE);
        g.fillRect(0, (int) (0.85 * h), w+10, (int) (0.15 * h+10));

        g.setColor(Color.YELLOW);
        g.fillOval((int) (-0.15 * h), (int) (-0.15 * h), (int) (0.3 * h), (int) (0.3 * h));

        g.setColor(Color.WHITE);
        g.fillOval((int) (w / 2 - 0.15 * w), (int) (0.7 * h), (int) (0.3 * w), (int) (0.2 * h));

        g.fillOval((int) (w / 2 - 0.125 * w),
                (int) (0.6 * h),
                (int) (0.25 * w),
                (int) (0.15 * h));

        g.fillOval((int) (w / 2 - 0.075 * w),
                (int) (0.5 * h),
                (int) (0.15 * w),
                (int) (0.15 * h));
        g.setColor(Color.BLACK);

        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(3));

        g.drawLine((int) (w / 2 - 0.1 * w),
                (int) (0.52 * h),
                (int) (w / 2 + 0.1 * w),
                (int) (0.52 * h));

        g2.setStroke(new BasicStroke(1));
        g.fillRect((int) (w / 2 - 0.06 * w),
                (int) (0.4 * h),
                (int) (0.12 * w),
                (int) (0.12 * h));
        
        g.fillRect((int) (w / 2 - 0.044 * w),
                (int) (0.54 * h),
                (int) (0.02 * w),
                (int) (0.02 * h));
        
        g.fillRect((int) (w / 2 + 0.024 * w),
                (int) (0.54 * h),
                (int) (0.02 * w),
                (int) (0.02 * h));
        
        g2.setStroke(new BasicStroke(3));
        g.drawArc((int) (w / 2 - 0.044 * w),
                (int)(0.56 *h),
                (int)(0.088*w),
                (int)(0.04*h),
                180, 180);
        
        g.drawLine((int)(w/2 -0.1*w),
                (int)(0.675 *h),
                (int)(w/2 -0.22*w),
                (int)(0.6 *h));
        
        
        g.drawLine((int)(w/2 + 0.1*w),
                (int)(0.675 *h),
                (int)(w/2 +0.22*w),
                (int)(0.675 *h));
        

    }

}

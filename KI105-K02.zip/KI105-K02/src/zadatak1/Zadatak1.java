/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zadatak1;

import javax.swing.JFrame;

/**
 *
 * @author Jovana
 */
public class Zadatak1 extends JFrame{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Zadatak1();
        
    }
    
    public Zadatak1(){
        setSize(500,500);
        setTitle("Snesko");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setContentPane(new SneskoPanel());
        setVisible(true);
    }
}

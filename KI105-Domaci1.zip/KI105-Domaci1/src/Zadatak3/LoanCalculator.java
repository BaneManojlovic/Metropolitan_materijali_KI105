package Zadatak3;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.TextField;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class LoanCalculator extends JFrame {

    public static void main(String[] args) {

        new LoanCalculator();

    }

    public LoanCalculator() {

        setTitle("Loan Payment Calculator");
        setSize(405, 380);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setupGUI();
        setResizable(false);
        setVisible(true);

    }

    public void setupGUI() {
        
        
        //sever levo
        JPanel l1 = new JPanel(new BorderLayout(10, 10));
        
        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.CENTER));
        p2.add(new JLabel("Amount of Loan"));
        
        JPanel p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.CENTER));
        p1.add(new JTextField(8));
        
        l1.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        l1.add(p2, BorderLayout.NORTH);
        l1.add(p1, BorderLayout.CENTER);
        
        
        //centar levo
        JPanel l2 = new JPanel(new BorderLayout(10, 10));
        
        JPanel par = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        par.add(new JLabel("Number of Years"));
        par.add(new JTextField(3) );
        
        JPanel par2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        par2.add(new JLabel("Interest Rate"));
        JComboBox<String> kombo = new JComboBox<>();
        kombo.addItem("5.25");
        //kombo.setPreferredSize(new Dimension(4,4));
        par2.add(kombo);
        
        l2.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        l2.add(par, BorderLayout.NORTH);
        l2.add(par2, BorderLayout.CENTER);
        
        
        //jug levo
        
        JPanel l3 = new JPanel(new BorderLayout(10, 10));
        
        JPanel p3 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        p3.add(new JButton("Calculate"));
        
        JPanel p4 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        p4.add(new JButton("Clear"));
        
        l3.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        l3.add(p3, BorderLayout.NORTH);
        l3.add(p4, BorderLayout.CENTER);
        
        
        JPanel levi = new JPanel(new BorderLayout(10, 10));
        
        levi.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        levi.add(l1, BorderLayout.NORTH);
        levi.add(l2, BorderLayout.CENTER);
        levi.add(l3, BorderLayout.SOUTH);
        
        
        
        //sever desno
        JPanel l4 = new JPanel(new BorderLayout(10, 10));
        
        JPanel p5 = new JPanel();
        p5.setLayout(new FlowLayout(FlowLayout.CENTER));
        p5.add(new JLabel("Monthly Payment"));
        
        JPanel p6 = new JPanel();
        p6.setLayout(new FlowLayout(FlowLayout.CENTER));
        p6.add(new JTextField(8));
        
        l4.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        l4.add(p5, BorderLayout.NORTH);
        l4.add(p6, BorderLayout.CENTER);
        
        
        //centar desno
        JPanel l5 = new JPanel(new BorderLayout(10, 10));
        
        JPanel p7 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        p7.add(new JLabel("Total Interest Paid"));
        
        JPanel p8 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        p8.add(new JTextField(8) );
        
        JPanel p9 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        p9.add(new JButton("Quit"));
        
        l5.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        l5.add(p7, BorderLayout.NORTH);
        l5.add(p8, BorderLayout.CENTER);
        l5.add(p9, BorderLayout.SOUTH);
        
        JPanel desni = new JPanel(new BorderLayout(10, 10));
        
        desni.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        desni.add(l4, BorderLayout.NORTH);
        desni.add(l5, BorderLayout.CENTER);
        
        
        JPanel glavni = new JPanel(new BorderLayout()); 
        
        glavni.add(levi, BorderLayout.WEST);
        glavni.add(desni, BorderLayout.CENTER);
        
        add(glavni);
        
    }
    
}



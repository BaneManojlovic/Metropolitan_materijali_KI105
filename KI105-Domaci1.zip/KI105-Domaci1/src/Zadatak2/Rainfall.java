
package Zadatak2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;



public class Rainfall extends JFrame{
    
    public static void main(String[] args) {

        new Rainfall();

    }
    
    public Rainfall(){
        
        setTitle("Rain statistics");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setupGUI();
        setResizable(false);
        setVisible(true);
        
    }
    
    public void setupGUI(){
        
        JPanel p1 = new JPanel();
        
        p1.setLayout(new FlowLayout(FlowLayout.LEFT, 1, 1));
        p1.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        p1.add(new JLabel("Enter rainfall measurements separated by space"));
        
        
        JPanel p2 = new JPanel(new GridLayout(1, 1));
        JTextArea Txt = new JTextArea();
        p2.add(Txt);
        p2.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        //p2.setBorder(new LineBorder(Color.BLUE, 1));
        //p2.setBorder(new TitledBorder(""));
        
        
        
        JButton Btn = new JButton("Calculate Statistics");
        
        JPanel labelsPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        labelsPanel.add(new JLabel("Total"));
        labelsPanel.add(new JLabel("Number"));
        labelsPanel.add(new JLabel("Average"));
        
        JPanel filedsPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        filedsPanel.add(new JTextField());
        filedsPanel.add(new JTextField());
        filedsPanel.add(new JTextField());
        
        JPanel South = new JPanel(new BorderLayout(10, 10));
       
        South.add(Btn,BorderLayout.NORTH);
        South.add(labelsPanel,BorderLayout.WEST);
        South.add( filedsPanel,BorderLayout.CENTER);
        
        JPanel SouthWest = new JPanel(new BorderLayout(10, 10));
        
        SouthWest.add(South,BorderLayout.WEST);
        SouthWest.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        
        
        
        add(p1, BorderLayout.NORTH);
        add(p2, BorderLayout.CENTER);
        add(SouthWest, BorderLayout.SOUTH);
    }
    
}

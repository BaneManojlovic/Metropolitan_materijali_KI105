package Zadatak4;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Zadatak4 extends JFrame {

    public static void main(String[] args) {

        new Zadatak4();

    }

    public Zadatak4() {

        setTitle("Subscription Form");
        setSize(405, 380);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setupGUI();
        setResizable(false);
        setVisible(true);

    }

    public void setupGUI() {
        
        
        //panel sa labelama koje su pravnate desno
        
        JPanel lablePane = new JPanel();
        lablePane.setLayout(new BoxLayout(lablePane, BoxLayout.PAGE_AXIS));

        JLabel l1 = new JLabel("Name: ");
        l1.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JLabel l2 = new JLabel("Email: ");
        l2.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JLabel l3 = new JLabel("Password: ");
        l3.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JLabel l4 = new JLabel("Zip code: ");
        l4.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JLabel l5 = new JLabel("Year of Birth: ");
        l5.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JLabel l6 = new JLabel("Phone number: ");
        l6.setAlignmentX(Component.RIGHT_ALIGNMENT);

        lablePane.add(l1);
        lablePane.add(Box.createVerticalStrut(5));
        lablePane.add(l2);
        lablePane.add(Box.createVerticalStrut(5));
        lablePane.add(l3);
        lablePane.add(Box.createVerticalStrut(5));
        lablePane.add(l4);
        lablePane.add(Box.createVerticalStrut(5));
        lablePane.add(l5);
        lablePane.add(Box.createVerticalStrut(4));
        lablePane.add(l6);
        
        //panel sa tekstualnim poljima
        JPanel textPane = new JPanel();
        textPane.setLayout(new BoxLayout(textPane, BoxLayout.PAGE_AXIS));

        for (int i = 1; i <= 6; i++) {
            JTextField t1 = new JTextField();
            //t1.setAlignmentX( Component.LEFT_ALIGNMENT );
            textPane.add(t1);
        }

        //panle sa labelama i tekstualnim poljima
        JPanel Pane2 = new JPanel();
        Pane2.setLayout(new GridLayout(1, 2, 10, 10));

        Pane2.add(lablePane);
        Pane2.add(textPane);

        //tekst prostor
        JTextArea tekstArea = new JTextArea();

        //panel za dugme
        JPanel dugmePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton btn = new JButton("Insert");
        dugmePanel.add(btn);

        //glavni panel
        JPanel lablePane3 = new JPanel(new BorderLayout(10, 10));
        lablePane3.setBorder(new EmptyBorder(10, 10, 10, 10));

        lablePane3.add(Pane2, BorderLayout.NORTH);
        lablePane3.add(tekstArea, BorderLayout.CENTER);
        lablePane3.add(dugmePanel, BorderLayout.SOUTH);

        add(lablePane3);

    }

}

package Zadatak1;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Calculator extends JFrame {

    public static void main(String[] args) {

        new Calculator();

    }

    public Calculator() {

        setTitle("Calculator");
        setSize(300, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setupGUI();
        setResizable(false);
        setVisible(true);
        //pack();
    }

    public void setupGUI() {
        
        JPanel p1 = new JPanel();
        p1.setLayout(new GridLayout(4, 3, 10, 10));
        p1.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10))); // okvir za p1
        // Dodavanje dugmadi na panel 
        for (int i = 1; i <= 9; i++) {
            p1.add(new JButton("" + i));
        }
        
        p1.add(new JButton("" + 0));
        p1.add(new JButton("" + "."));
        

        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 1, 1));
        p2.add(new JTextField(15));
        p2.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));
        

        JPanel p3 = new JPanel();
        p3.setLayout(new GridLayout(4, 1, 10, 10));
        p3.setBorder(new EmptyBorder(new Insets(10, 20, 10, 10)));
        p3.add(new JButton("+"));
        p3.add(new JButton("="));
        p3.add(new JButton("Clear"));
        

        add(p1, BorderLayout.CENTER);
        add(p2, BorderLayout.NORTH);
        add(p3, BorderLayout.EAST);
    }

}

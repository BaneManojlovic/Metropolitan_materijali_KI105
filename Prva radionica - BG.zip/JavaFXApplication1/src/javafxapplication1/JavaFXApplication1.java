/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication1;

 

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author profesor
 */
public class JavaFXApplication1 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button();
        btn.setText("Say 'Hello World'");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
        

        BorderPane root = new BorderPane();     
        
        
        ToggleGroup firstGroup = new ToggleGroup();
        HBox hbox = new HBox();
        RadioButton left = new RadioButton("Left");
        RadioButton center = new RadioButton("Center");
        RadioButton right = new RadioButton("Right");
        left.setToggleGroup(firstGroup);
        center.setToggleGroup(firstGroup);
        right.setToggleGroup(firstGroup);
        center.setSelected(true);
        hbox.getChildren().addAll(left,center,right);
        
                
        
        ToggleGroup secondGroup = new ToggleGroup();
        HBox hboxBottom = new HBox();
        RadioButton top = new RadioButton("Top");
        RadioButton middle = new RadioButton("Middle");
        RadioButton bottom = new RadioButton("Bottom");
        top.setToggleGroup(secondGroup);
        middle.setToggleGroup(secondGroup);
        bottom.setToggleGroup(secondGroup);
        middle.setSelected(true);
        hboxBottom.getChildren().addAll(top,middle,bottom);
        
        VBox vbox = new VBox();
        CheckBox text = new CheckBox("Text");
        CheckBox icon = new CheckBox("Icon");
        vbox.getChildren().addAll(text,icon);
        
        
        ComboBox comboBox = new ComboBox();
        comboBox.getItems().addAll("Red","Green","Blue");
        
        Label label = new Label("Cross");
        Image img = new Image(getClass().getResourceAsStream("x.png"));
        ImageView imgView = new ImageView(img);
        imgView.setFitWidth(30);
        imgView.setFitHeight(30);
        label.setGraphic(imgView);
        
        
        
        root.setCenter(label);
        root.setRight(comboBox);
        root.setLeft(vbox);
        root.setTop(hbox);
        root.setBottom(hboxBottom);        
 
        BorderPane.setAlignment(label, Pos.BOTTOM_RIGHT);
       
        top.setOnAction(e -> { 
            
                        if(left.isSelected()){
                           BorderPane.setAlignment(label, Pos.TOP_LEFT); 
                        }                       
                        if(right.isSelected()){
                           BorderPane.setAlignment(label, Pos.TOP_RIGHT); 
                        } 
                        if(center.isSelected()){
                           BorderPane.setAlignment(label, Pos.TOP_CENTER); 
                        }                         
                    });
        
        
         middle.setOnAction(e -> { 
            
                        if(left.isSelected()){
                           BorderPane.setAlignment(label, Pos.CENTER_LEFT); 
                        }                       
                        if(right.isSelected()){
                           BorderPane.setAlignment(label, Pos.CENTER_RIGHT); 
                        } 
                        if(center.isSelected()){
                           BorderPane.setAlignment(label, Pos.CENTER); 
                        }                         
                    });
         
        Font font = new Font("Arial",14);        
        label.setTextFill(Color.RED);
        
        comboBox.getSelectionModel().select(0);
        comboBox.setOnAction((event) -> {
            System.out.println(comboBox.valueProperty().getValue());
             
            if(comboBox.valueProperty().getValue() == "Red"){
                   label.setTextFill(Color.RED);
            }
            
            if(comboBox.valueProperty().getValue() == "Blue"){
                   label.setTextFill(Color.BLUE);
            }
            
            if(comboBox.valueProperty().getValue() == "Green"){
                   label.setTextFill(Color.GREEN);
            }
  
        });
        
        text.setSelected(true);
        text.selectedProperty().addListener(e -> {
            if(text.isSelected()){
                label.setText("Cross");
            }
            else{
                label.setText("");
            }
        });
        icon.setSelected(true);
        icon.selectedProperty().addListener(e -> {
            if(icon.isSelected()){
                label.setGraphic(imgView);
            }
            else{
                label.setGraphic(null);
            }
        });
        
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

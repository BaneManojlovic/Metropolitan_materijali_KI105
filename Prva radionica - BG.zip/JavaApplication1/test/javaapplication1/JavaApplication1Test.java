/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author profesor
 */
public class JavaApplication1Test {
    
    public JavaApplication1Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

 
    /**
     * Test of add method, of class JavaApplication1.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        int a = 0;
        int b = 0;
        int expResult = 0;
        int result = JavaApplication1.add(a, b);
        assertEquals(expResult, result);        
    }
    
     @Test
    public void testAdd1() {
        System.out.println("add");
        int a = 5;
        int b = 5;
        int expResult = 10;
        int result = JavaApplication1.add(a, b);
        assertEquals(expResult, result);        
    }
    
      @Test
    public void testAdd2() {
        System.out.println("add");
        int a = -1;
        int b = 1;
        int expResult = 0;
        int result = JavaApplication1.add(a, b);
        assertEquals(expResult, result);        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication2;


import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author profesor
 */
public class JavaFXApplication2 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
      
        
        StackPane root = new StackPane();
        //root.getChildren().add(btn);
        
        TextField txt = new TextField();
     // root.getChildren().add(txt);
//        Double broj = Double.parseDouble(txt.getText());
        
        Rectangle rt = new Rectangle();
        rt.setWidth(100);
        rt.setHeight(100);
        root.getChildren().add(rt);
        
        RotateTransition rotation = new RotateTransition(Duration.millis(1000), rt);
  
        rotation.setCycleCount(RotateTransition.INDEFINITE);
        rotation.setAutoReverse(true);
        
            
        
        Button btn = new Button();
        btn.setText("Play");
        btn.setOnAction(e -> { 
             rotation.setFromAngle(Integer.parseInt(txt.getText()));
             rotation.setToAngle(Integer.parseInt(txt.getText()));
            rotation.play();
        });
        
        root.getChildren().add(btn);

        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

package Zadatak1;

import java.awt.*;
import javax.swing.JPanel;

public class FigurePanel extends JPanel {

    // Deklaracija konstanti
    public static final int LINE = 1;
    public static final int OVAL = 2;
    private int type = 1;

    // Konstruktor početnog FigurePanel objekta
    public FigurePanel() {
    }

    // Konstruktor objekta FigurePanel određenog tipa
    public FigurePanel(int type) {
        this.type = type;
    }

    @Override // Crta figuru na panelu
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Dobijanje odrešene veličine figure na panelu
        int width = getWidth();
        int height = getHeight();
        switch (type) {
            case LINE: // Prikaz dve ukrštene linije
                g.setColor(Color.BLACK);
                g.drawLine(10, 10, width - 10, height - 10);
                g.drawLine(width - 10, 10, 10, height - 10);
                break;

            case OVAL: // Prikaz elipse
                g.setColor(Color.BLACK);
                g.drawOval((int) (0.1 * width), (int) (0.1 * height), (int) (0.8 * width), (int) (0.8 * height));

        }
    }

    @Override // Definisanje nove veličine
    public Dimension getPreferredSize() {
        return new Dimension(80, 80);
    }
}

package Zadatak1;

import java.awt.*;
import javax.swing.*;

public class Zadatak1 extends JFrame {

    public Zadatak1() {
        setLayout(new GridLayout(3, 3, 5, 5));
        add(new FigurePanel(FigurePanel.OVAL));
        add(new JLabel(""));
        add(new FigurePanel(FigurePanel.OVAL));
        add(new FigurePanel(FigurePanel.OVAL));
        add(new FigurePanel(FigurePanel.LINE));
        add(new FigurePanel(FigurePanel.OVAL));
        add(new FigurePanel(FigurePanel.LINE));
        add(new FigurePanel(FigurePanel.OVAL));
        add(new FigurePanel(FigurePanel.OVAL));

    }

    public static void main(String[] args) {
        Zadatak1 frame = new Zadatak1();
        frame.setSize(400, 250);
        frame.setTitle("Iks-Oks");
        frame.setLocationRelativeTo(null); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

}

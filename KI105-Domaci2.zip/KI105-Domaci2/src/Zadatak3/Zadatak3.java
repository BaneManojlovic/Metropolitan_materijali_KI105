package Zadatak3;

import Zadatak2.Valjak;
import java.awt.GridLayout;
import javax.swing.JFrame;

public class Zadatak3 extends JFrame {

    public Zadatak3() {

        setLayout(new GridLayout(2, 2, 5, 5));
        for (int i = 1; i <= 4; i++) {
            add(new Kaleidoskop());
        }
    }

    public static void main(String[] args) {

        Zadatak3 frame = new Zadatak3();
        frame.setSize(300, 300);
        frame.setTitle("Kaleidoskop");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.setContentPane(new Kaleidoskop());
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }

}

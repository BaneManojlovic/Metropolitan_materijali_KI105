package Zadatak3;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Kaleidoskop extends JPanel {

    @Override // Crta figuru na panelu
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int width = getWidth();
        int height = getHeight();

        g.setColor(Color.BLACK);
        g.drawOval((int) (0.1 * width), (int) (0.1 * height), (int) (0.8 * width), (int) (0.8 * height));

        g.fillArc((int) (0.125 * width), (int) (0.125 * height), (int) (0.75 * width), (int) (0.75 * height), 10, 25);
        g.fillArc((int) (0.125 * width), (int) (0.125 * height), (int) (0.75 * width), (int) (0.75 * height), 100, 25);
        g.fillArc((int) (0.125 * width), (int) (0.125 * height), (int) (0.75 * width), (int) (0.75 * height), 190, 25);
        g.fillArc((int) (0.125 * width), (int) (0.125 * height), (int) (0.75 * width), (int) (0.75 * height), 280, 25);

    }

    /* Definisanje nove veličine
    @Override 
    public Dimension getPreferredSize() {      
        return new Dimension(80, 80);
    } */
}

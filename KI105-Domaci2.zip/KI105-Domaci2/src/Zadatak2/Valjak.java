package Zadatak2;

import java.awt.Graphics;
import javax.swing.JPanel;

public class Valjak extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int width = getWidth();
        int height = getHeight();

        g.drawOval((int) (width * 0.2), (int) (0.09 * height),
                (int) (0.6 * width), (int) (0.19 * height));

        g.drawLine((int) (width * 0.2), (int) (height * 0.185),
                (int) (width * 0.2), (int) (height * 0.75));

        g.drawLine((int) (width * 0.8), (int) (height * 0.185),
                (int) (width * 0.8), (int) (height * 0.75));

        g.drawArc((int) (width * 0.2), (int) (height * 0.655),
                (int) (0.6 * width), (int) (0.19 * height), 0, -180);

        g.drawArc((int) (width * 0.2), (int) (height * 0.655),
                (int) (0.6 * width), (int) (0.19 * height), 0, 20);

        g.drawArc((int) (width * 0.2), (int) (height * 0.655),
                (int) (0.6 * width), (int) (0.19 * height), 40, 20);

        g.drawArc((int) (width * 0.2), (int) (height * 0.655),
                (int) (0.6 * width), (int) (0.19 * height), 80, 20);

        g.drawArc((int) (width * 0.2), (int) (height * 0.655),
                (int) (0.6 * width), (int) (0.19 * height), 120, 20);

        g.drawArc((int) (width * 0.2), (int) (height * 0.655),
                (int) (0.6 * width), (int) (0.19 * height), 160, 20);

    }

}

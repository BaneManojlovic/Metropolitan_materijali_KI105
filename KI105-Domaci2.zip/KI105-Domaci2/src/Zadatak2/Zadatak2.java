package Zadatak2;

import javax.swing.JFrame;

public class Zadatak2 extends JFrame {

    public Zadatak2() {
        setSize(350, 400);
        setTitle("Valjak");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(new Valjak());
        setLocationRelativeTo(null);
        setVisible(true);

    }

    public static void main(String[] args) {

        new Zadatak2();

    }

}

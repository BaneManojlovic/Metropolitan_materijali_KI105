
package Zadatak4;

import javax.swing.JFrame;

public class Zadatak4 extends JFrame {
    
    public Zadatak4() {
        setSize(300, 300);
        setTitle("Pakman");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(new Pakman());
        setLocationRelativeTo(null);
        setVisible(true);

    }

    public static void main(String[] args) {

        new Zadatak4();

    }
    
}


package Zadatak4;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Pakman extends JPanel {
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int width = getWidth();
        int height = getHeight();
        
        
        g.setColor(Color.YELLOW);
        g.fillArc((int) (0.1 * width), (int) (0.1 * height), (int) (0.8 * width), (int) (0.8 * height),30,305);
        
        g.setColor(Color.BLACK);
        g.fillOval((int) (0.5 * width), (int) (0.25 * height), (int) (0.125 * width),(int)(0.125 * height));
        
        
    }
    
}
